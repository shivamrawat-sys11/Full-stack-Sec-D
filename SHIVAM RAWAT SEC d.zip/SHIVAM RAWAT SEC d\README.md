# Express JWT Authentication (`SHIVAM RAWAT SEC d`)

## Aim
To implement user registration, login, and a protected route using JSON Web Tokens (JWT) in an Express application.

## Setup & Run
1. Install dependencies:
   ```bash
   npm install
   ```
2. Start the server:
   ```bash
   npm start
   ```
   Open `http://localhost:3000` in your browser to use the interactive web UI.
3. Run tests:
   ```bash
   npm test
   ```

## API Endpoints
- **`POST /register`**: `{ username, password }`
  - `201`: `{ "message": "User registered" }`
  - `400`: `{ "error": "Invalid input" }` (missing/empty username or password < 6 chars)
  - `409`: `{ "error": "Username already exists" }`
- **`POST /login`**: `{ username, password }`
  - `200`: `{ "token": "<jwt>" }` (contains `username`, expires in 1 hour)
  - `401`: `{ "error": "Invalid credentials" }`
- **`GET /profile`**: Header `Authorization: Bearer <token>`
  - `200`: `{ "username": "<username>" }`
  - `401`: `{ "error": "Unauthorized" }`
