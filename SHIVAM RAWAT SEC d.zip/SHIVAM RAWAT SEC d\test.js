const assert = require('assert');
const http = require('http');
const jwt = require('jsonwebtoken');
const app = require('./app');

function request(server, method, path, { body, headers = {} } = {}) {
  return new Promise((resolve, reject) => {
    const addr = server.address();
    const payload = body ? JSON.stringify(body) : null;
    const req = http.request(
      {
        hostname: '127.0.0.1',
        port: addr.port,
        path,
        method,
        headers: {
          ...(payload ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) } : {}),
          ...headers,
        },
      },
      (res) => {
        let data = '';
        res.on('data', (chunk) => (data += chunk));
        res.on('end', () => {
          resolve({ status: res.statusCode, body: JSON.parse(data) });
        });
      }
    );
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

async function runTests() {
  const server = app.listen(0);
  try {
    // 1. Missing/empty username or short password -> 400
    let res = await request(server, 'POST', '/register', { body: { username: '', password: 'password123' } });
    assert.strictEqual(res.status, 400);
    assert.deepStrictEqual(res.body, { error: 'Invalid input' });

    res = await request(server, 'POST', '/register', { body: { username: 'alice', password: '123' } });
    assert.strictEqual(res.status, 400);
    assert.deepStrictEqual(res.body, { error: 'Invalid input' });

    // 2. Valid registration -> 201
    res = await request(server, 'POST', '/register', { body: { username: 'alice', password: 'password123' } });
    assert.strictEqual(res.status, 201);
    assert.deepStrictEqual(res.body, { message: 'User registered' });

    // 3. Duplicate username -> 409
    res = await request(server, 'POST', '/register', { body: { username: 'alice', password: 'password123' } });
    assert.strictEqual(res.status, 409);
    assert.deepStrictEqual(res.body, { error: 'Username already exists' });

    // 4. Invalid login -> 401
    res = await request(server, 'POST', '/login', { body: { username: 'bob', password: 'password123' } });
    assert.strictEqual(res.status, 401);
    assert.deepStrictEqual(res.body, { error: 'Invalid credentials' });

    res = await request(server, 'POST', '/login', { body: { username: 'alice', password: 'wrongpassword' } });
    assert.strictEqual(res.status, 401);
    assert.deepStrictEqual(res.body, { error: 'Invalid credentials' });

    // 5. Valid login -> 200 with JWT containing username & 1h expiry
    res = await request(server, 'POST', '/login', { body: { username: 'alice', password: 'password123' } });
    assert.strictEqual(res.status, 200);
    assert.ok(res.body.token);
    const decoded = jwt.decode(res.body.token);
    assert.strictEqual(decoded.username, 'alice');
    assert.strictEqual(decoded.exp - decoded.iat, 3600);

    const token = res.body.token;

    // 6. GET /profile with valid token -> 200
    res = await request(server, 'GET', '/profile', {
      headers: { Authorization: `Bearer ${token}` },
    });
    assert.strictEqual(res.status, 200);
    assert.deepStrictEqual(res.body, { username: 'alice' });

    // 7. GET /profile with missing/invalid/expired token -> 401
    res = await request(server, 'GET', '/profile');
    assert.strictEqual(res.status, 401);
    assert.deepStrictEqual(res.body, { error: 'Unauthorized' });

    res = await request(server, 'GET', '/profile', {
      headers: { Authorization: 'Bearer malformed.token.here' },
    });
    assert.strictEqual(res.status, 401);
    assert.deepStrictEqual(res.body, { error: 'Unauthorized' });

    const wrongSigToken = jwt.sign({ username: 'alice' }, 'wrong-secret', { expiresIn: '1h' });
    res = await request(server, 'GET', '/profile', {
      headers: { Authorization: `Bearer ${wrongSigToken}` },
    });
    assert.strictEqual(res.status, 401);
    assert.deepStrictEqual(res.body, { error: 'Unauthorized' });

    const expiredToken = jwt.sign({ username: 'alice' }, 'super-secret-jwt-key', { expiresIn: -10 });
    res = await request(server, 'GET', '/profile', {
      headers: { Authorization: `Bearer ${expiredToken}` },
    });
    assert.strictEqual(res.status, 401);
    assert.deepStrictEqual(res.body, { error: 'Unauthorized' });

    console.log('All tests passed successfully!');
  } finally {
    server.close();
  }
}

runTests().catch((err) => {
  console.error(err);
  process.exit(1);
});
